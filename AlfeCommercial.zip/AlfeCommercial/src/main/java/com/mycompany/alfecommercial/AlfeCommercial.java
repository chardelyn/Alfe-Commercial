/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.alfecommercial;

/**
 *
 * @author Admin
 */
public class AlfeCommercial {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
