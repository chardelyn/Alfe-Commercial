-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2026 at 04:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alfe_commercial`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_history`
--

CREATE TABLE `login_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `logout_time` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_history`
--

INSERT INTO `login_history` (`id`, `user_id`, `username`, `role`, `login_time`, `logout_time`) VALUES
(14, 1, 'admin', 'Admin', '2026-10-02 06:56:38', NULL),
(15, 1, 'jharyl', 'Admin', '2026-10-06 07:01:40', NULL),
(16, 3, 'chardelyn', 'Cashier', '2026-10-06 07:01:55', NULL),
(17, 1, 'jharyl', 'Admin', '2026-10-08 01:29:02', NULL),
(18, 3, 'chardelyn', 'Cashier', '2026-10-08 01:37:46', NULL),
(19, 3, 'chardelyn', 'Cashier', '2026-10-08 01:37:48', NULL),
(20, 4, 'john', 'Cashier', '2026-10-08 01:38:52', NULL),
(21, 4, 'john', 'Cashier', '2026-10-08 01:38:53', NULL),
(22, 1, 'jharyl', 'Admin', '2026-10-08 01:39:03', NULL),
(23, 4, 'john', 'Cashier', '2026-10-08 01:40:52', NULL),
(24, 4, 'john', 'Cashier', '2026-10-08 02:31:47', NULL),
(25, 4, 'john', 'Cashier', '2026-10-08 02:32:02', NULL),
(26, 1, 'jharyl', 'Admin', '2026-10-08 02:40:29', NULL),
(27, 4, 'john', 'Cashier', '2026-10-08 02:40:48', NULL),
(28, 1, 'jharyl', 'Admin', '2026-10-08 02:41:33', NULL),
(29, 4, 'john', 'Cashier', '2026-10-08 02:42:32', NULL),
(30, 4, 'john', 'Cashier', '2026-10-08 02:42:41', NULL),
(31, 1, 'jharyl', 'Admin', '2026-10-09 07:07:06', NULL),
(32, 4, 'john', 'Cashier', '2026-10-09 07:07:23', NULL),
(33, 4, 'john', 'Cashier', '2026-10-09 07:07:31', NULL),
(34, 4, 'john', 'Cashier', '2026-10-09 08:10:19', NULL),
(35, 1, 'jharyl', 'Admin', '2026-10-09 08:11:20', NULL),
(36, 3, 'chardelyn', 'Cashier', '2026-10-09 08:12:01', NULL),
(37, 4, 'john', 'Cashier', '2026-10-09 08:13:27', NULL),
(38, 1, 'jharyl', 'Admin', '2026-10-10 05:23:23', NULL),
(39, 1, 'jharyl', 'Admin', '2026-10-10 05:28:19', NULL),
(40, 4, 'john', 'Cashier', '2026-10-10 05:29:33', NULL),
(41, 4, 'john', 'Cashier', '2026-10-10 05:30:06', NULL),
(42, 4, 'john', 'Cashier', '2026-10-10 05:32:41', NULL),
(43, 1, 'jharyl', 'Admin', '2026-10-10 05:34:09', NULL),
(44, 1, 'jharyl', 'Admin', '2026-10-10 06:57:31', NULL),
(45, 1, 'jharyl', 'Admin', '2026-10-10 07:03:23', NULL),
(46, 4, 'john', 'Cashier', '2026-10-10 07:04:58', NULL),
(47, 1, 'jharyl', 'Admin', '2026-10-10 07:08:10', NULL),
(48, 1, 'jharyl', 'Admin', '2026-10-10 07:28:42', NULL),
(49, 1, 'jharyl', 'Admin', '2026-10-10 07:30:10', NULL),
(50, 1, 'jharyl', 'Admin', '2026-10-10 11:15:55', NULL),
(51, 1, 'jharyl', 'Admin', '2026-10-10 11:16:30', NULL),
(52, 1, 'jharyl', 'Admin', '2026-10-10 11:56:01', NULL),
(53, 4, 'john', 'Cashier', '2026-10-10 12:00:50', NULL),
(54, 1, 'jharyl', 'Admin', '2026-10-10 12:01:08', NULL),
(55, 2, 'maria', 'Admin', '2026-10-10 12:05:31', NULL),
(56, 2, 'maria', 'Admin', '2026-10-10 12:16:28', NULL),
(57, 2, 'maria', 'Admin', '2026-10-10 12:23:33', NULL),
(58, 3, 'chardelyn', 'Cashier', '2026-10-10 12:28:12', NULL),
(59, 2, 'maria', 'Admin', '2026-10-10 13:53:34', NULL),
(60, 2, 'maria', 'Admin', '2026-10-10 13:54:56', NULL),
(61, 2, 'maria', 'Admin', '2026-10-10 13:55:56', NULL),
(62, 1, 'jharyl', 'Admin', '2026-10-10 14:09:34', NULL),
(63, 2, 'maria', 'Admin', '2026-10-11 02:11:54', NULL),
(64, 2, 'maria', 'Admin', '2026-10-11 02:43:45', NULL),
(65, 4, 'john', 'Cashier', '2026-10-11 02:49:38', NULL),
(66, 2, 'maria', 'Admin', '2026-10-11 02:49:54', NULL),
(67, 2, 'maria', 'Admin', '2026-10-11 03:24:26', NULL),
(68, 2, 'maria', 'Admin', '2026-10-11 05:07:43', NULL),
(69, 2, 'maria', 'Admin', '2026-10-11 05:32:43', NULL),
(70, 2, 'maria', 'Admin', '2026-10-11 05:40:49', NULL),
(71, 2, 'maria', 'Admin', '2026-10-11 05:42:46', NULL),
(72, 1, 'jharyl', 'Admin', '2026-10-11 05:45:41', NULL),
(73, 1, 'jharyl', 'Admin', '2026-10-11 05:47:51', NULL),
(74, 1, 'jharyl', 'Admin', '2026-10-11 05:53:32', NULL),
(75, 1, 'jharyl', 'Admin', '2026-10-11 05:55:33', NULL),
(76, 2, 'maria', 'Admin', '2026-10-11 05:56:30', NULL),
(77, 2, 'maria', 'Admin', '2026-10-11 06:08:33', NULL),
(78, 2, 'maria', 'Admin', '2026-10-11 06:09:38', NULL),
(79, 2, 'maria', 'Admin', '2026-10-11 11:05:39', NULL),
(80, 2, 'maria', 'Admin', '2026-10-11 11:23:47', NULL),
(81, 4, 'john', 'Cashier', '2026-10-11 11:54:17', NULL),
(82, 2, 'maria', 'Admin', '2026-10-11 11:54:53', NULL),
(83, 2, 'maria', 'Admin', '2026-10-11 11:59:17', NULL),
(84, 4, 'john', 'Cashier', '2026-10-11 11:59:55', NULL),
(85, 2, 'maria', 'Admin', '2026-10-11 12:43:14', NULL),
(86, 2, 'maria', 'Admin', '2026-10-11 12:43:58', NULL),
(87, 2, 'maria', 'Admin', '2026-10-11 12:46:14', NULL),
(88, 2, 'maria', 'Admin', '2026-10-11 12:50:46', NULL),
(89, 2, 'maria', 'Admin', '2026-10-11 13:21:09', NULL),
(90, 2, 'maria', 'Admin', '2026-10-11 13:21:50', NULL),
(91, 2, 'maria', 'Admin', '2026-10-11 13:23:35', NULL),
(92, 2, 'maria', 'Admin', '2026-10-11 13:23:38', NULL),
(93, 2, 'maria', 'Admin', '2026-10-11 13:23:47', NULL),
(94, 2, 'maria', 'Admin', '2026-10-11 13:24:21', NULL),
(95, 4, 'john', 'Cashier', '2026-10-11 13:26:40', NULL),
(96, 2, 'maria', 'Admin', '2026-10-11 13:29:11', NULL),
(97, 2, 'maria', 'Admin', '2026-10-11 13:29:25', NULL),
(98, 2, 'maria', 'Admin', '2026-10-11 13:30:48', NULL),
(99, 2, 'maria', 'Admin', '2026-10-11 13:33:12', NULL),
(100, 2, 'maria', 'Admin', '2026-10-11 13:35:01', NULL),
(101, 2, 'maria', 'Admin', '2026-10-11 13:36:25', NULL),
(102, 2, 'maria', 'Admin', '2026-10-12 00:46:16', NULL),
(103, 2, 'maria', 'Admin', '2026-10-12 00:47:34', NULL),
(104, 2, 'maria', 'Admin', '2026-10-12 01:02:33', NULL),
(105, 2, 'maria', 'Admin', '2026-10-12 01:03:23', NULL),
(106, 2, 'maria', 'Admin', '2026-10-12 01:04:48', NULL),
(107, 2, 'maria', 'Admin', '2026-10-12 01:05:34', NULL),
(108, 2, 'maria', 'Admin', '2026-10-12 01:06:16', NULL),
(109, 2, 'maria', 'Admin', '2026-10-12 01:07:58', NULL),
(110, 2, 'maria', 'Admin', '2026-10-12 01:08:51', NULL),
(111, 2, 'maria', 'Admin', '2026-10-12 01:09:35', NULL),
(112, 2, 'maria', 'Admin', '2026-10-12 01:12:26', NULL),
(113, 2, 'maria', 'Admin', '2026-10-12 01:15:34', NULL),
(114, 2, 'maria', 'Admin', '2026-10-12 01:21:30', NULL),
(115, 2, 'maria', 'Admin', '2026-10-12 01:24:04', NULL),
(116, 2, 'maria', 'Admin', '2026-10-12 01:28:45', NULL),
(117, 2, 'maria', 'Admin', '2026-10-12 01:36:08', NULL),
(118, 2, 'maria', 'Admin', '2026-10-12 01:37:39', NULL),
(119, 2, 'maria', 'Admin', '2026-10-12 01:45:18', NULL),
(120, 2, 'maria', 'Admin', '2026-10-12 01:49:22', NULL),
(121, 2, 'maria', 'Admin', '2026-10-12 04:29:57', NULL),
(122, 2, 'maria', 'Admin', '2026-10-12 04:36:17', NULL),
(123, 2, 'maria', 'Admin', '2026-10-12 07:57:15', NULL),
(124, 2, 'maria', 'Admin', '2026-10-12 07:59:36', NULL),
(125, 2, 'maria', 'Admin', '2026-10-12 08:04:25', NULL),
(126, 2, 'maria', 'Admin', '2026-10-12 09:58:02', NULL),
(127, 2, 'maria', 'Admin', '2026-10-12 12:04:08', NULL),
(128, 2, 'maria', 'Admin', '2026-10-12 13:02:23', NULL),
(129, 2, 'maria', 'Admin', '2026-10-12 13:11:10', NULL),
(130, 2, 'maria', 'Admin', '2026-10-12 13:18:55', NULL),
(131, 2, 'maria', 'Admin', '2026-10-12 13:22:06', NULL),
(132, 3, 'chardelyn', 'Cashier', '2026-10-12 13:29:02', NULL),
(133, 1, 'jharyl', 'Admin', '2026-10-12 13:33:08', NULL),
(134, 2, 'maria', 'Admin', '2026-10-12 13:54:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_recovery`
--

CREATE TABLE `password_recovery` (
  `id` int(11) NOT NULL,
  `role` varchar(20) NOT NULL,
  `recovery_code_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_recovery`
--

INSERT INTO `password_recovery` (`id`, `role`, `recovery_code_hash`) VALUES
(1, 'Admin', '68b9678cbd978ea0772e6ba3052f58aa3e1dd60c10bdb27cae6bc3f9bc2fc0e1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `variant` varchar(100) DEFAULT NULL,
  `size` varchar(50) DEFAULT NULL,
  `specification` varchar(150) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `status` varchar(20) NOT NULL DEFAULT 'In Stock',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_id`, `name`, `category`, `brand`, `variant`, `size`, `specification`, `color`, `unit`, `price`, `stock`, `status`, `created_at`) VALUES
(14, 'PRD-657472', 'Pencil', 'School Supplies', NULL, NULL, NULL, NULL, NULL, NULL, 10.00, 4, 'ACTIVE', '2026-10-02 05:55:19'),
(15, 'PRD-677697', 'Marker', 'Office Supplies', NULL, NULL, NULL, NULL, NULL, NULL, 25.00, 150, 'In Stock', '2026-10-02 05:55:44'),
(16, 'PRD-843230', 'Yellow Paper', 'School Supplies', NULL, NULL, NULL, NULL, NULL, NULL, 50.00, 0, 'Out of Stock', '2026-10-02 05:56:15'),
(17, 'PRD-614100', 'HDMI', 'Electronics', 'Dell', NULL, '1 Meter', NULL, 'Black', 'Piece', 150.00, 1007, 'In Stock', '2026-10-02 05:56:34'),
(18, 'PRD-217566', 'Bondpaper', 'School Supplies', 'Double A', 'Premium', 'A4', '80 GSM', 'White', 'Ream', 250.00, 2012, 'In Stock', '2026-10-07 14:25:48'),
(19, 'PRD-430372', 'Ballpen', 'School Supplies', 'Panda', '0', '0', '0', 'Black', '0', 10.00, 999, 'In Stock', '2026-10-10 12:27:06');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `transaction_id` varchar(20) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment` decimal(10,2) NOT NULL,
  `change_amount` decimal(10,2) NOT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_method` varchar(30) NOT NULL DEFAULT 'Cash',
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `transaction_id`, `total_amount`, `payment`, `change_amount`, `sale_date`, `payment_method`, `user_id`) VALUES
(8, 'TRX-321367', 250.00, 300.00, 50.00, '2026-10-02 06:09:42', 'GCash', NULL),
(9, 'TRX-716131', 250.00, 300.00, 50.00, '2026-10-02 06:59:19', 'Cash', NULL),
(10, 'TRX-914748', 375.00, 375.00, 0.00, '2026-10-02 06:59:47', 'GCash', NULL),
(11, 'TRX-602336', 250.00, 250.00, 0.00, '2026-10-02 07:00:05', 'Maya', NULL),
(12, 'TRX-918142', 375.00, 375.00, 0.00, '2026-10-02 07:00:19', 'Card', NULL),
(13, 'TRX-609939', 50.00, 100.00, 50.00, '2026-10-07 12:47:40', 'Cash', NULL),
(14, 'TRX-928553', 150.00, 200.00, 50.00, '2026-10-08 01:22:02', 'Cash', 0),
(15, 'TRX-899228', 150.00, 200.00, 50.00, '2026-10-08 02:43:17', 'Cash', 4),
(16, 'TRX-514812', 225.00, 250.00, 25.00, '2026-10-09 08:11:11', 'Cash', 4),
(17, 'TRX-253474', 975.00, 1000.00, 25.00, '2026-10-09 08:12:51', 'Cash', 3),
(18, 'TRX-743525', 500.00, 1000.00, 500.00, '2026-10-10 05:33:55', 'Cash', 4),
(19, 'TRX-163343', 10.00, 10.00, 0.00, '2026-10-11 05:12:06', 'GCash', 2),
(20, 'TRX-494870', 2000.00, 2500.00, 500.00, '2026-10-12 13:31:03', 'Card', 3);

-- --------------------------------------------------------

--
-- Table structure for table `sale_items`
--

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sale_items`
--

INSERT INTO `sale_items` (`id`, `sale_id`, `product_id`, `quantity`, `price`, `subtotal`) VALUES
(8, 8, 'PRD-677697', 10, 25.00, 250.00),
(9, 9, 'PRD-677697', 10, 25.00, 250.00),
(10, 10, 'PRD-677697', 15, 25.00, 375.00),
(11, 11, 'PRD-677697', 10, 25.00, 250.00),
(12, 12, 'PRD-677697', 15, 25.00, 375.00),
(13, 13, 'PRD-843230', 1, 50.00, 50.00),
(14, 14, 'PRD-614100', 1, 150.00, 150.00),
(15, 15, 'PRD-614100', 1, 150.00, 150.00),
(16, 16, 'PRD-614100', 1, 150.00, 150.00),
(17, 16, 'PRD-677697', 1, 25.00, 25.00),
(18, 16, 'PRD-843230', 1, 50.00, 50.00),
(19, 17, 'PRD-843230', 19, 50.00, 950.00),
(20, 17, 'PRD-677697', 1, 25.00, 25.00),
(21, 18, 'PRD-843230', 10, 50.00, 500.00),
(22, 19, 'PRD-430372', 1, 10.00, 10.00),
(23, 20, 'PRD-217566', 8, 250.00, 2000.00);

-- --------------------------------------------------------

--
-- Table structure for table `stock_history`
--

CREATE TABLE `stock_history` (
  `id` int(11) NOT NULL,
  `product_id` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_type` enum('STOCK IN','STOCK OUT','ADJUSTMENT','SALE') NOT NULL,
  `quantity_changed` int(11) NOT NULL,
  `stock_before` int(11) NOT NULL,
  `stock_after` int(11) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_history`
--

INSERT INTO `stock_history` (`id`, `product_id`, `user_id`, `action_type`, `quantity_changed`, `stock_before`, `stock_after`, `reason`, `sale_id`, `created_at`) VALUES
(1, 'PRD-843230', 1, 'STOCK IN', 100, 29, 129, 'Manual stock in', NULL, '2026-10-10 05:23:31'),
(2, 'PRD-217566', 1, 'STOCK IN', 1000, 1020, 2020, 'Manual stock in', NULL, '2026-10-10 05:28:33'),
(3, 'PRD-614100', 2, 'STOCK IN', 1000, 7, 1007, 'Manual stock in', NULL, '2026-10-11 02:13:09'),
(4, 'PRD-657472', 2, 'STOCK IN', 5000, 5, 5005, 'Manual stock in', NULL, '2026-10-11 02:13:16'),
(5, 'PRD-657472', 2, 'STOCK OUT', -5001, 5005, 4, 'Manual stock out', NULL, '2026-10-11 05:09:11'),
(6, 'PRD-677697', 2, 'STOCK OUT', -13, 13, 0, 'Manual stock out', NULL, '2026-10-11 05:09:17'),
(7, 'PRD-677697', 2, 'STOCK IN', 100, 0, 100, 'Manual stock in', NULL, '2026-10-12 13:13:22'),
(8, 'PRD-677697', 2, 'STOCK OUT', -90, 100, 10, 'Manual stock out', NULL, '2026-10-12 13:13:31'),
(9, 'PRD-677697', 2, 'STOCK IN', 90, 10, 100, 'Manual stock in', NULL, '2026-10-12 13:13:43'),
(10, 'PRD-677697', 2, 'STOCK OUT', -10, 100, 90, 'Manual stock out', NULL, '2026-10-12 13:13:48'),
(11, 'PRD-677697', 2, 'STOCK OUT', -80, 90, 10, 'Manual stock out', NULL, '2026-10-12 13:13:55'),
(12, 'PRD-677697', 2, 'ADJUSTMENT', 90, 10, 100, 'Manual stock adjustment', NULL, '2026-10-12 13:14:01'),
(13, 'PRD-677697', 2, 'STOCK IN', 50, 100, 150, 'Manual stock in', NULL, '2026-10-12 13:14:09'),
(14, 'PRD-677697', 2, 'STOCK IN', 150, 150, 300, 'Manual stock in', NULL, '2026-10-12 13:14:26'),
(15, 'PRD-677697', 2, 'ADJUSTMENT', -150, 300, 150, 'Manual stock adjustment', NULL, '2026-10-12 13:14:33'),
(16, 'PRD-677697', 2, 'STOCK OUT', -140, 150, 10, 'Manual stock out', NULL, '2026-10-12 13:14:51'),
(17, 'PRD-677697', 2, 'STOCK IN', 150, 10, 160, 'Manual stock in', NULL, '2026-10-12 13:24:10'),
(18, 'PRD-677697', 2, 'STOCK OUT', -150, 160, 10, 'Manual stock out', NULL, '2026-10-12 13:24:20'),
(19, 'PRD-677697', 2, 'ADJUSTMENT', 140, 10, 150, 'Manual stock adjustment', NULL, '2026-10-12 13:24:27'),
(20, 'PRD-677697', 2, 'ADJUSTMENT', 150, 150, 300, 'Manual stock adjustment', NULL, '2026-10-12 13:24:35'),
(21, 'PRD-677697', 2, 'ADJUSTMENT', -150, 300, 150, 'Manual stock adjustment', NULL, '2026-10-12 13:24:42'),
(22, 'PRD-843230', 2, 'ADJUSTMENT', -119, 119, 0, 'Manual stock adjustment', NULL, '2026-10-12 13:25:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'Jharyl R.', 'Rufino', 'jharyl', 'gortgort', 'Admin', '2026-09-29 13:24:11'),
(2, 'Maria Mechaela Samri', 'Cuajao', 'maria', 'mariamaria', 'Admin', '2026-10-06 06:55:52'),
(3, 'Chardelyn', 'Bienes', 'chardelyn', 'lynlyn', 'Cashier', '2026-10-06 06:55:52'),
(4, 'John Lloyd Fernando', 'Corro', 'john', 'johnjohn', 'Cashier', '2026-10-06 06:55:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_history`
--
ALTER TABLE `login_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_recovery`
--
ALTER TABLE `password_recovery`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role` (`role`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transaction_id` (`transaction_id`);

--
-- Indexes for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `sale_id` (`sale_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_history`
--
ALTER TABLE `login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `password_recovery`
--
ALTER TABLE `password_recovery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sale_items`
--
ALTER TABLE `sale_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `stock_history`
--
ALTER TABLE `stock_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sale_items`
--
ALTER TABLE `sale_items`
  ADD CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`);

--
-- Constraints for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD CONSTRAINT `stock_history_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `stock_history_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `stock_history_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
